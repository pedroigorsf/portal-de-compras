$(function () {
    $('select').selectpicker();
});