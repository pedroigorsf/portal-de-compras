
<footer id="footer" class="py-5">

<div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Portal de Compras</span></strong>.
      </div>

    </div>
  </footer>

</body>

</html>